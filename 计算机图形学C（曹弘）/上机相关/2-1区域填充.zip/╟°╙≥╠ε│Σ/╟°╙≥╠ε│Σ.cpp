﻿// 区域填充3.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <cmath>
#include <stack>
#include "gl/glut.h"
using namespace std;
#define PI 3.14

void Display();
void DrawGrid();
void Drawtri(int x, int y, int color);
void FourConnected(int x, int y);
void ScanFill(int x, int y);
void mouse(GLint button, GLint action, GLint x, GLint y);

struct Position
{
	int x;
	int y;
	Position()
	{
		x = 0;
		y = 0;
	};
	Position(int px, int py)
	{
		x = px;
		y = py;
	};
};

stack<Position> sta;
int a[24][24] = { 0 };

void Display()
{
	glClear(GL_COLOR_BUFFER_BIT);
	DrawGrid();
	glFlush();
}

void DrawGrid()
{
	glColor3f(0.0, 0.0, 0.0);		//格子颜色，黑色
	glBegin(GL_LINES);
	for (int i = 0; i < 600; i += 25)
	{
		glVertex2f(i, 0);
		glVertex2f(i, 600);
	}
	for (int j = 0; j < 600; j += 25)
	{
		glVertex2f(0, j);
		glVertex2f(600, j);
	}
	glEnd();
	for (int k = 0; k < 24; k++)
	{
		for (int l = 0; l < 24; l++)
		{
			if (a[k][l] == 1)
			{
				Drawtri(k * 25 + 12, l * 25 + 12, 1);
			}
			else if (a[k][l] == 2)
			{
				Drawtri(k * 25 + 12, l * 25 + 12, 2);
			}
		}
	}
}

void Drawtri(int x, int y, int color)
{
	double n = 200;
	float R = 10;
	int i;
	if (color == 1)
	{
		glColor3f(0.0, 0.0, 0.0);	//点颜色
	}
	else if (color == 2)
	{
		glColor3f(1.0, 0.0, 0.0);	//填充颜色
	}
	glBegin(GL_POLYGON);
	glVertex2f(x, y);
	for (i = 0; i <= n; i++)
		glVertex2f(R * cos(2 * PI / n * i) + x, R * sin(2 * PI / n * i) + y);
	glEnd();
	glPopMatrix();
}

void FourConnected(int x, int y)
{
	if (x < 0 || y < 0 || x>23 || y>23)
		return;
	if (a[x][y] == 0)
	{
		a[x][y] = 2;
		FourConnected(x - 1, y);
		FourConnected(x + 1, y);
		FourConnected(x, y - 1);
		FourConnected(x, y + 1);
	}
}

void ScanFill(int x, int y)
{
	if (a[x][y] != 0)
		return;
	Position first(x, y);
	sta.push(first);
	while (!sta.empty())
	{
		int rightX = 0;
		int leftX = 0;
		Position cur = sta.top();
		sta.pop();
		a[cur.x][cur.y] = 2;
		for (int i = 1; i < 24; i++)
		{
			if (cur.x + i < 24)
			{
				if (a[cur.x + i][cur.y] == 0)
					a[cur.x + i][cur.y] = 2;
				else
				{
					rightX = cur.x + i - 1;
					break;
				}
			}
			if (i == 23)
			{
				rightX = 23;
			}
		}
		for (int i = 1; i < 24; i++)
		{
			if (cur.x - i > -1)
			{
				if (a[cur.x - i][cur.y] == 0)
					a[cur.x - i][cur.y] = 2;
				else
				{
					leftX = cur.x - i + 1; break;
				}
			}
			if (i == 0)
			{
				leftX = 0;
			}
		}
		cout << leftX << "," << rightX << endl;
		int upRightX = -1;
		for (int i = leftX; i <= rightX; i++)
		{
			if (a[i][cur.y + 1] == 0 && cur.y + 1 < 24)
			{
				upRightX = i;
			}
		}
		if (upRightX != -1)
		{
			Position temPos(upRightX, cur.y + 1);
			sta.push(temPos);
		}

		int downRightX = -1;
		for (int i = leftX; i <= rightX; i++)
		{
			if (a[i][cur.y - 1] == 0 && cur.y - 1 >= 0)
			{
				downRightX = i;
			}
		}
		if (downRightX != -1)
		{
			Position temPos(downRightX, cur.y - 1);
			sta.push(temPos);
		}
	}
}

void mouse(GLint button, GLint action, GLint x, GLint y)
{
	int curX, curY;
	if (button == GLUT_LEFT_BUTTON && action == GLUT_DOWN)
	{
		curX = x / 25;
		curY = (600 - y) / 25;
		a[curX][curY] = 1;
		glutPostRedisplay();
	}
	if (button == GLUT_RIGHT_BUTTON && action == GLUT_DOWN)
	{
		curX = x / 25;
		curY = (600 - y) / 25;
		ScanFill(curX, curY);
		glutPostRedisplay();
	}
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(600, 600);
	glutCreateWindow("区域填充");
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0.0, 600.0, 0.0, 600.0);
	glPointSize(12.0f);
	glutDisplayFunc(Display);
	glutMouseFunc(mouse);
	glutMainLoop();
	return 0;
}
