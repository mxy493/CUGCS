﻿#include<iostream>
#include "gl/glut.h"
using namespace std;
#define YES 1
#define NO 0
int Drawing;

//菜单
void Menu(int value)
{
	Drawing = value;
	glutPostRedisplay();
}

//初始化
void Initialization()
{
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);	//背景色，白色
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_DST_ALPHA);
	glEnable(GL_POINT_SMOOTH);
	glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
	glEnable(GL_LINE_SMOOTH);
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	Drawing = NO;
}

//未处理
void Original(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	if (Drawing == YES)
		glEnable(GL_BLEND);
	else
		glDisable(GL_BLEND);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);	//画笔颜色，黑色
	glLineWidth(10);
	glBegin(GL_LINE_LOOP);
	glVertex2f(-2.0f, -2.0f);
	glVertex2f(0.0f, 2.0f);
	glVertex2f(2.0f, 0.0f);
	glEnd();
	glutSwapBuffers();
}

//反走样处理
void AntiAliasing(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	if (h != 0)
	{
		GLfloat aspect = (float)w / (float)h;
		if (w < h)
			gluOrtho2D(-3, 3, -3 * aspect, 3 * aspect);
		else
			gluOrtho2D(-3 / aspect, 3 / aspect, -3, 3);
	}
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

int main(int argc, char* argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(600, 480);
	glutCreateWindow("反走样");
	glutReshapeFunc(AntiAliasing);
	glutDisplayFunc(Original);
	glutCreateMenu(Menu);
	Initialization();
	glutAddMenuEntry("Original", NO);
	glutAddMenuEntry("Antialiasing", YES);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	glutMainLoop();
	return 0;
}
