#include "stdafx.h"
#include "ModuleStackNode.h"


ModuleStackNode::ModuleStackNode(int s, int z, ModuleStackNode *next)
{
	sIndex = s;
	zIndex = z;
	this->next = next;
}

