#include<iostream.h>

template<class T>
struct Treenode
{
	T data;
	int key;
	Treenode<T> * leftchild , * rightchild;
	Treenode(){ leftchilde = NULL; rightchild = NULL;}
	Treenode(T & x , Treenode<T> * l = NULL,Treenode<T> * r = NULL){data = x; leftchild = l; rightchild = r;}
};

template <class T> class Tree
{
	protected:
		Treenode<T> * root;
		T revalue;
	public:
		Tree(){root = NULL;}
		~Tree(){delete root;}
		Tree( T & x) {revalue = x;root = NULL;}
		Treenode<T> * createTree(T *VLR , T *LVR , int n);
		Treenode<T> * CreateTree(T *LRV , T *LVR , int n);
		void preorder(Treenode<T> * p);
		void midorder(Treenode<T> * p , int n);
		void midorder(Treenode<T> * p);
		void behorder(Treenode<T> * p);
		Treenode<T> * getroot() {return root;}
		
		 
}; 


template <class T> Treenode<T> * Tree<T>::createTree(T *VLR , T *LVR , int n)  //�����ǰ�����й��������
{
	if(n==0) return NULL;
	int k = 0;
	while(LVR[k]!=VLR[0] && k<n-1){k++; }
	Treenode<T> * t = new Treenode<T>(VLR[0]);
	t->leftchild = createTree( VLR+1,LVR,k);
	t->rightchild = createTree( VLR+k+1,LVR+k+1,n-k-1);
	return t;

}

template<class T> Treenode<T> * Tree<T>::CreateTree(T *LRV , T *LVR , int n)  //������������й��������
{
	if(n==0) return NULL;
	int k =0;
	while(LRV[0] != LVR[k]) {k++;}
	Treenode<T> * t = new Treenode<T>(LRV[0]);
	t->rightchild = CreateTree(LRV+1,LVR,k);
	t->leftchild = CreateTree(LRV+k+1,LVR+k+1,n-k-1);

	return t;
}


template<class T> void Tree<T>::preorder (Treenode<T> * p)  //ǰ�����
{
	if( p != NULL)
	{
		cout<<p->data;
		preorder(p->leftchild); 
		preorder(p->rightchild); 
	}
}



template<class T> void Tree<T>::midorder (Treenode<T> * p)  //�������
{
	if(p != NULL)
	{
		midorder(p->leftchild);
		cout<<p->data;
		midorder(p->rightchild);
	}
}

template<class T> void Tree<T>::behorder (Treenode<T> * p)  //�������
{
	if(p != NULL)
	{
		behorder(p->leftchild);
		behorder(p->rightchild);
		cout<<p->data;
	}
}

template<class T> void Tree<T>::midorder (Treenode<T> * p,int n)  //���뷨�������
{
	if(p != NULL)
	{
		midorder(p->rightchild,n+1);
		for(int i=0;i<n;i++)
		{
			cout<<"     ";
		}

		if(p!=root) cout<<"----";
		
		cout<<p->data<<endl;
		midorder(p->leftchild,n+1);
			
	}
}