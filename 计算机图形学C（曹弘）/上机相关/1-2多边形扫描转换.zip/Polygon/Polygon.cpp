﻿// Polygon.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream> 
#include <vector> 
#include <windows.h>
#include "GL/glut.h"
using namespace std;

//窗口宽高
const int windowWidth = 400;
const int windowHeight = 300;

//定义用于边表ET和活动边表AET的通用类Edge
class Edge
{
public:
	int ymax;
	float x;
	float dx;
	Edge* next;
};

Edge* ET[windowHeight];		//边表
Edge* AET;					//活动边表 

//定义用于表示像素点坐标的类Point
class Point
{
public:
	int x;
	int y;
	Point(int x, int y)
	{
		this->x = x;
		this->y = y;
	}
};

//三角形
vector<Point> vertices = { Point(40, 60), Point(200, 200), Point(300, 100) };
//四边形 
//vector<Point> vertices = { Point(40, 40), Point(100, 240), Point(240, 220), Point(300, 100) };

void Pixelfill(GLint x, GLint y)
{
	glColor3f(1.0f, 0.0f, 0.0f);	//设定颜色为红色
	//glPointSize(3.0);				//点大小为3像素（减少生成时间）
	glBegin(GL_POINTS);
	glVertex2i(x, y);
	glEnd();
	glFlush();			//强制刷新缓冲
}

//多边形扫描填充
void polygonScan()
{
	//清空显示窗口并设置画点颜色为红色 
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glBegin(GL_POINTS);
	//计算最高点的y坐标 
	int maxY = 0;
	for (unsigned int i = 0; i < vertices.size(); i++)
	{
		if (vertices[i].y > maxY)
		{
			maxY = vertices[i].y;
		}
	}
	//初始化ET和AET 
	Edge* pET[windowHeight];
	for (int i = 0; i < maxY; i++)
	{
		pET[i] = new Edge();
		pET[i]->next = nullptr;
	}
	AET = new Edge();
	AET->next = nullptr;
	//建立边表ET 
	for (int i = 0; i < vertices.size(); i++)
	{
		//取出当前点1前后相邻的共4个点，点1与点2的连线作为本次循环处理的边，另外两个点点0和点3用于计算奇点
		int x0 = vertices[(i - 1 + vertices.size()) % vertices.size()].x;
		int x1 = vertices[i].x;
		int x2 = vertices[(i + 1) % vertices.size()].x;
		int x3 = vertices[(i + 2) % vertices.size()].x;
		int y0 = vertices[(i - 1 + vertices.size()) % vertices.size()].y;
		int y1 = vertices[i].y;
		int y2 = vertices[(i + 1) % vertices.size()].y;
		int y3 = vertices[(i + 2) % vertices.size()].y;
		//水平线直接舍弃 
		if (y1 == y2) continue;
		//分别计算下端点y坐标、上端点y坐标、下端点x坐标和斜率倒数 
		int ymin = y1 > y2 ? y2 : y1;
		int ymax = y1 > y2 ? y1 : y2;
		float x = y1 > y2 ? x2 : x1;
		float dx = (x1 - x2) * 1.0f / (y1 - y2);
		//奇点特殊处理，若点2->1->0的y坐标单调递减则y1为奇点，若点1->2->3的y坐标单调递减则y2为奇点 
		if (((y1 < y2) && (y1 > y0)) || ((y2 < y1) && (y2 > y3)))
		{
			ymin++;
			x += dx;
		}
		//创建新边，插入边表ET
		Edge* p = new Edge();
		p->ymax = ymax;
		p->x = x;
		p->dx = dx;
		p->next = pET[ymin]->next;
		pET[ymin]->next = p;
	}
	//扫描线从下往上扫描，y坐标每次加1 
	for (int i = 0; i < maxY; i++) {
		//取出ET中当前扫描行的所有边并按x的递增顺序（若x相等则按dx的递增顺序）插入AET 
		while (pET[i]->next)
		{
			//取出ET中当前扫描行表头位置的边 
			Edge* pInsert = pET[i]->next;
			Edge* p = AET;
			//在AET中搜索合适的插入位置
			while (p->next)
			{
				if (pInsert->x > p->next->x)
				{
					p = p->next;
					continue;
				}
				if (pInsert->x == p->next->x && pInsert->dx > p->next->dx)
				{
					p = p->next;
					continue;
				}
				//找到位置 
				break;
			}
			//将pInsert从ET中删除，并插入AET的当前位置
			pET[i]->next = pInsert->next;
			pInsert->next = p->next;
			p->next = pInsert;
		}
		//AET中的边两两配对并填色
		Edge* p = AET;
		while (p->next && p->next->next)
		{
			for (int x = p->next->x; x < p->next->next->x; x++)
			{
				Pixelfill(x, i);
			}
			p = p->next->next;
		}
		//删除AET中满足y=ymax的边
		p = AET;
		while (p->next)
		{
			if (p->next->ymax == i)
			{
				Edge* pDelete = p->next;
				p->next = pDelete->next;
				pDelete->next = nullptr;
				delete pDelete;
			}
			else
			{
				p = p->next;
			}
		} //更新AET中边的x值，进入下一循环 
		p = AET;
		while (p->next)
		{
			p->next->x += p->next->dx;
			p = p->next;
		}
	}

	glEnd();
	glutSwapBuffers();
}

void changeSize(int w, int h) {

	// Prevent a divide by zero, when window is too short
	// (you cant make a window of zero width).
	if (h == 0)
		h = 1;

	float ratio = w * 1.0 / h;

	// Use the Projection Matrix
	glMatrixMode(GL_PROJECTION);

	// Reset Matrix
	glLoadIdentity();

	// Set the viewport to be the entire window
	glViewport(0, 0, w, h);

	// Set the correct perspective.
	gluPerspective(45, ratio, 1, 100);

	// Get Back to the Modelview
	glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100, 100);					//设置窗口位置
	glutInitWindowSize(windowWidth, windowHeight);		//设置窗口大小
	glutCreateWindow("多边形扫描转换");					//创建窗口
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0.0, windowWidth, 0.0, windowHeight);	//定义一个二维图像投影矩阵
	glutDisplayFunc(polygonScan);						//注册绘图函数polygonScan()

	//glutReshapeFunc(changeSize);

	glutMainLoop();			//循环绘图
	return 0;
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
