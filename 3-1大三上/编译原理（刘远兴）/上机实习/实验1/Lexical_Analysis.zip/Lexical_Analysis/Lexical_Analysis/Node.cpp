#include "stdafx.h"

Node::Node(int index)
{
	this->index = index;
	setAdjoinTable(NULL);
}

void Node::setAdjoinTable(AdjoinNode *firstNode ) {
	adjoinTable = firstNode;
}

AdjoinNode* Node::getAdjoinTable() {
	return adjoinTable;
}

void Node::addAdjoinNode(AdjoinNode* newNode) {
	newNode->setNext(adjoinTable);
	adjoinTable = newNode;
}