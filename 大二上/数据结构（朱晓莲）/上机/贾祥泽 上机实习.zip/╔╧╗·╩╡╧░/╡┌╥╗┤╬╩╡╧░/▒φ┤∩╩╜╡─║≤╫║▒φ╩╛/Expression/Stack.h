#include<iostream>

template<class T> class Stack
{
	private:
		T * elements;
		int top;
		int maxsize;
	public:
		Stack(int sz = 50);
		~Stack() {delete []elements;}
		void Push (  T & x);
		bool Pop ( T & x);
		bool IsEmpty() const { return (top == -1) ? true:false ;}
		bool getTop (T & x);

};

template<class T> Stack<T>::Stack(int sz)
{
	top = -1;
	maxsize = sz;
	elements = new T [maxsize];

}

template<class T> void Stack<T> ::Push ( T & x)
{
	elements[++top] = x;
}

template<class T> bool Stack<T> ::Pop (T & x)
{
	if(IsEmpty() == true) return false;

	x = elements[top--];
	return true;
}

template<class T> bool Stack<T> ::getTop (T & x)
{
	if(IsEmpty() == true ) return false;

	x = elements[top];
	return true;
}

