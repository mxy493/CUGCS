#include "stdafx.h"
#include "ModuleStack.h"


ModuleStack::ModuleStack()
{
	top = NULL;
}

void ModuleStack::push(ModuleStackNode* newNode) {
	top = newNode;
}

ModuleStackNode* ModuleStack::pop() {
	ModuleStackNode *oldNode = top;
	if (top == NULL) return NULL;
	top = top->next;
	return oldNode;
}
