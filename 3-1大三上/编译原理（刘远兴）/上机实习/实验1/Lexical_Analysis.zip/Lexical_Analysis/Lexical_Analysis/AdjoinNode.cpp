#include "stdafx.h"


AdjoinNode::AdjoinNode(int index, char condition)
{
	this->index = index;
	this->condition = condition;
	setNext(NULL);
}

AdjoinNode* AdjoinNode::next() {
	return _next;
}

void AdjoinNode::setNext(AdjoinNode *next) {
	_next = next;
}