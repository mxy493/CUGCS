#include "stdafx.h"
#include "AssistStackNode.h"


AssistStackNode::AssistStackNode(char s, AssistStackNode* next)
{
	symbol = s;
	this->next = next;
}