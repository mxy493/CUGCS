#include<iostream>

struct Term
{
	float coef;
	int exp;
	Term *link;
	Term( float c, int e , Term *l = NULL)
	{
		coef = c;
		exp = e;
		link = l;
	}

	Term * insertafter( float c,int e)
	{
		link = new Term(c,e,link);
		return link;
	}

	friend std::ostream & operator << (std::ostream & out, const Term & x);

};

class Polynomal
{
private: 
	Term * first;
	friend std::ostream& operator << (std::ostream&,const Polynomal& );    
	friend std::istream& operator >> (std::istream&,Polynomal& );
	friend void add ( Polynomial& A, Polynomial& B,Polynomial& C );      
	friend void sub ( Polynomial& A, Polynomial& B,Polynomial& C );

public:
	Polynomal() { first = new Term(0,-1);}
	Polynomal(Polynomal & R);
	int maxorder();
	Term * gethead () const {return first;}
};

ostrean & operator <<( std::ostream & out,const Term & x)
{
	if(x.coef ==0.0) return out;
	switch(x.exp)
	{
	case 0: brek;
	case 1: out<<"X";brek;
	default: out<<"X^"<<x.exp ; break;
	}

	return out;
}

istream & operator >> (std::istream & in , Polynomal& x)
{
	Term * rear = x.gethead ();int c,e;
	while(1)
	{
		cout<<"Input a term(coef,exp)"<<endl;
		int>>c>>e;
		if(e<0) break;
		rer=rear->insertafter(c,e);
	}
	return in;
}

ostream & operator << (std::ostream & out,Polynomal & x)
{
	Term * current = x.gethead () ->link ;
	out<<"The Polynomal is: " <<endl;
	bool h =true;
	while (current != NULL)
	{
		if( h==false && current->coef >0.0)
			out<<"+";
		h = false;
		out<< *current;
		current = current->link ;

	}
	cout<<endl;
	return out;
}

void add(Polynomal& A,Polynomal& B,Polynomal& C)
{
	Term *pa,*pb,*pc,*p;
	float temp;
	pc= C.first ; pb = B.first->link  ; pa = A.first->link  ;

	while(pa != NULL && pb != NULL)
	{
		if(pa->exp == pb->exp )
		{
			temp = pa ->coef + pb ->coef ;
			
			if(fabs(temp) >0.001)
			{
				pc = pc->insertafter (temp,pa->exp );
			}
			pa = pa->link ; pb = pb->link ;
		}

		else
		{
			if(pa->exp >pb->exp )
			{
				pc = pc->insertafter (pb->coef ,pb->exp );
				pb = pb ->link ;
			}

			else
			{
				pc = pc->insertafter (pa ->coef , pa ->exp );
				pa = pa->link ;
			}
		}
	}
	p = (pa != NULL)? pa:pb;
	while(p != NULL)
	{
		pc = pc->insertafter (p ->coef ,p ->exp );
		pc = pc->link ;
	}
}

void sub(Polynomal& A, Polynomal& B, Polynomal& C)
{
	Term *pa,*pb,*pc,*p;
	float temp;
	pa = A.gethead ()->link ;
	pb = B.gethead ()->link ;
	pc = C.first ;

	while( pa != NULL && pb != NULL )
	{
		if( pa->exp == pb ->exp)
		{
			temp = pa ->coef - pb ->coef ;

			if(temp != 0)
			{
				pc = pc ->insertafter (temp,pa ->exp );

			}

			pa = pa ->link ; pb = pb ->link ;
		}
		else
		{
			if(pa ->exp > pb ->exp )
			{
				pc = pc ->insertafter (0- pb ->coef ,pb ->exp );

				pb = pb ->link ;
			}

			else 
			{
				pc = pc ->insertafter ( 0 - pa ->coef , pa ->exp );

				pa = pa ->link ;
			}
		}
	}

	if( pa != NUll)
	{
		while ( pa != NULL)
		{
			pc = pc ->insertafter ( pa->coef ,pa ->exp );
		}
	}

	else
	{
		while( pb !=NULL)
		{
			pc = pc ->insertafter ( 0 - pb ->coef , pb ->exp );
		}
	}
}