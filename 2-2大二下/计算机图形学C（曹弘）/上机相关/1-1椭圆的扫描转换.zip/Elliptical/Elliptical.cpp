﻿// Elliptical.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
// 椭圆的扫描转换

#include <iostream>
#include <conio.h>
#include <GL/glut.h>
#include <graphics.h>

using namespace std;

double a, b;//长半轴a，短半轴b

/*Bresenham算法*/
void Bresenham(double a, double b)
{
	/*计算初始值*/
	double d = pow(b, 2) + pow(a, 2) * (-b + 0.25), x = 0, y = b;
	/*当b2(x+1)<a2(y-0.5)时，重复步骤(3)和(4)，否则转(6)*/
	/*(3)绘制点(x,y)及其在四分象限上的另外3个对称点.*/
	while (pow(b, 2) * (x + 1) < pow(a, 2) * (y - 0.5))
	{
		glVertex2d(x, y);//绘制点（x,y)
		glVertex2d(-x, y);
		glVertex2d(x, -y);
		glVertex2d(-x, -y);
		if (d <= 0)
		{
			d += pow(b, 2) * (2 * x + 3);
			x += 1;
		}
		else
		{
			d += pow(b, 2) * (2 * x + 3) + pow(a, 2) * (-2 * y + 2);
			x += 1;
			y -= 1;
		}
	}
	/*(6)用上半部分计算的最后点(x，y)来计算下半部分中d的初值*/
	d = pow(b, 2) * pow(x + 0.5, 2) + pow(a, 2) * pow(y - 1, 2) - pow(a, 2) * pow(b, 2);
	/*当y＞＝0时，重复步骤(7)和(8)，否则结束*/
	while (y >= 0)
	{
		/*(7)绘制点(x,y)及其在四分象限的另外3个对称点*/
		glVertex2d(x, y);//绘制点（x,y)
		glVertex2d(-x, y);
		glVertex2d(x, -y);
		glVertex2d(-x, -y);
		/*(8)判断d的符号*/
		if (d <= 0)
		{
			d = d + pow(b, 2) * (2 * x + 2) + pow(a, 2) * (-2 * y + 3);
			x += 1;
			y -= 1;
		}
		else
		{
			d += pow(a, 2) * (-2 * y + 3);
			y -= 1;
		}
	}
}

/*椭圆的外观*/
void ellipseSegment()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0, 0.0, 0.0);//设置点的颜色为红色
	glBegin(GL_POINTS);
	Bresenham(a, b);
	glEnd();
	glFlush();
}

int main(int argc, char* argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	cout << "输入椭圆的长半轴a，短半轴b：" << endl;
	cin >> a >> b;//输入长半轴、短半轴
	glutInitWindowPosition(50, 100);
	glutInitWindowSize(500, 500);
	glutCreateWindow("Bresenham 算法画椭圆");
	glClearColor(0, 0, 0, 0);
	glMatrixMode(GL_PROJECTION);		//指定当前矩阵，将后续矩阵运算应用于投影矩阵堆栈
	gluOrtho2D(-250, +250, -250, +250);	//定义二维正投影矩阵
	glutDisplayFunc(ellipseSegment);	//设置当前窗口的显示回调，参数直线的外观，见上面
	glutMainLoop();
	system(0);
	return 0;
}


// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
