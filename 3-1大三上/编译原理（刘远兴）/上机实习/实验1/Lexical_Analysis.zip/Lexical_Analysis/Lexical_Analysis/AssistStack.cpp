#include "stdafx.h"
#include "AssistStack.h"

AssistStack::AssistStack()
{
	top = NULL;
}

void AssistStack::push(AssistStackNode *newNode) {
	top = newNode;
}

AssistStackNode* AssistStack::pop() {
	AssistStackNode *oldNode = top;
	top = top->next;
	return oldNode;
}
