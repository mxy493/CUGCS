#include "stdafx.h"
#include "DFANode.h"


DFANode::DFANode(int index, set<int> list):Node(index)
{
	this->nfaSet = list;
}

DFANode::DFANode(int index) : Node(index) {

}

set<int> DFANode::getNFASet() {
	return nfaSet;
}

