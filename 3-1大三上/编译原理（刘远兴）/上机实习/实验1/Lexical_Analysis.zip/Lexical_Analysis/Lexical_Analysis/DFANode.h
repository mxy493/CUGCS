#pragma once
#include "Node.h"
#include <set>
//DFA�Ľ��
class DFANode :
	public Node
{
private:
	set<int> nfaSet;
public:
	DFANode(int index, set<int>);
	DFANode(int index);
	set<int> getNFASet();
};

